import '../style.css';
import { renderHeader } from './header';

renderHeader();